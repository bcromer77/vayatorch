"use client"

import { useEffect, useState } from "react"
import DealTicker from "./components/DealTicker"
import LuxuryCard from "./components/LuxuryCard"
import Navigation from "./components/Navigation"
import MyVaya from "./components/MyVaya"
import { getMockDeals } from "./data/mockDeals"
import { mockSavings } from "./types"

function App() {
  const [deals, setDeals] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [savings, setSavings] = useState(mockSavings)

  useEffect(() => {
    const fetchDeals = async () => {
      try {
        const data = await getMockDeals()
        setDeals(data)
      } catch (err) {
        console.error("Failed to fetch deals:", err)
        setError("Unable to load deals. Please try again later.")
      } finally {
        setLoading(false)
      }
    }
    fetchDeals()
  }, [])

  return (
    <div className="app">
      <div className="container">
        <Navigation />
        <header>
          <h1>Luxury Family Getaways</h1>
          <p className="subtitle">Exclusive deals for unforgettable experiences</p>
          <DealTicker deals={deals} />
        </header>
        <main>
          <section className="trending">
            <h2>Trending Destinations</h2>
            <p>Discover the most sought-after luxury escapes</p>
          </section>
          <div className="cards">
            {loading ? (
              <div className="loading">
                <div className="spinner"></div>
                <p>Curating exclusive deals just for you...</p>
              </div>
            ) : error ? (
              <div className="error-message">{error}</div>
            ) : (
              deals.map((deal) => <LuxuryCard key={deal.id} deal={deal} />)
            )}
          </div>

          {/* Add the MyVaya component */}
          <MyVaya savings={savings} />

          <button className="cta" onClick={() => alert("VIP Preview coming soon!")}>
            Join VIP Preview
          </button>
        </main>
        <footer>
          <p>&copy; 2023 VayaTorch Luxury Travel. All rights reserved.</p>
        </footer>
      </div>
      <style jsx>{`
        .app {
          background: linear-gradient(135deg, #121214 0%, #1e1e24 100%);
          color: rgba(255, 255, 255, 0.9);
          font-family: 'Inter', 'Helvetica Neue', sans-serif;
          min-height: 100vh;
          padding: 30px 20px;
        }
        
        .container {
          max-width: 1200px;
          margin: 0 auto;
        }
        
        header {
          text-align: center;
          margin-bottom: 40px;
        }
        
        h1 {
          background: linear-gradient(135deg, #d4af37 0%, #f5cc59 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          font-size: 3em;
          font-weight: 800;
          margin-bottom: 10px;
          letter-spacing: -0.5px;
        }
        
        .subtitle {
          color: rgba(255, 255, 255, 0.7);
          font-size: 1.2em;
          margin-bottom: 30px;
        }
        
        .trending {
          text-align: center;
          margin: 40px 0;
        }
        
        h2 {
          color: #d4af37;
          font-size: 2em;
          font-weight: 700;
          margin-bottom: 10px;
        }
        
        .trending p {
          color: rgba(255, 255, 255, 0.7);
        }
        
        .cards {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: 30px;
          margin-top: 30px;
        }
        
        .loading {
          grid-column: 1 / -1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 60px 0;
        }
        
        .spinner {
          width: 40px;
          height: 40px;
          border: 4px solid rgba(212, 175, 55, 0.3);
          border-top: 4px solid #d4af37;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin-bottom: 20px;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        .error-message {
          grid-column: 1 / -1;
          background: rgba(255, 107, 107, 0.1);
          color: #ff6b6b;
          text-align: center;
          padding: 30px;
          border-radius: 12px;
          border: 1px solid rgba(255, 107, 107, 0.3);
        }
        
        .cta {
          background: linear-gradient(135deg, #d4af37 0%, #f5cc59 100%);
          color: #000;
          border: none;
          padding: 16px 32px;
          border-radius: 30px;
          font-weight: 600;
          font-size: 1.1em;
          cursor: pointer;
          display: block;
          margin: 50px auto;
          transition: all 0.3s ease;
          letter-spacing: 0.5px;
          box-shadow: 0 10px 25px rgba(212, 175, 55, 0.4);
        }
        
        .cta:hover {
          transform: translateY(-3px);
          box-shadow: 0 15px 30px rgba(212, 175, 55, 0.5);
        }
        
        footer {
          text-align: center;
          margin-top: 60px;
          padding: 20px 0;
          color: rgba(255, 255, 255, 0.5);
          font-size: 0.9em;
        }
        
        @media (max-width: 768px) {
          h1 {
            font-size: 2.2em;
          }
          
          .cards {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  )
}

export default App

