// Using the Pexels API to get real images
const PEXELS_API_KEY = "kaaiCr4VD2dSst4EgPqD8whTY3jEomGZ9gUTGmlFp9kna35cROBKZ6OG"

// Pre-fetched Pexels image URLs for each destination to avoid API rate limits
const destinationImages = {
  "Bali, Indonesia": "https://images.pexels.com/photos/3225531/pexels-photo-3225531.jpeg",
  Maldives: "https://images.pexels.com/photos/1483053/pexels-photo-1483053.jpeg",
  "Santorini, Greece": "https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg",
  "Amalfi Coast, Italy": "https://images.pexels.com/photos/2512282/pexels-photo-2512282.jpeg",
  "Swiss Alps": "https://images.pexels.com/photos/290452/pexels-photo-290452.jpeg",
  "Kyoto, Japan": "https://images.pexels.com/photos/1440476/pexels-photo-1440476.jpeg",
}

export const getMockDeals = async (shouldFail = false) => {
  const mockDeals = [
    {
      id: 1,
      destination: "Bali, Indonesia",
      description: "5-night family villa + flights, kids' club included",
      price: "$3,000",
      originalPrice: "$3,750",
      image: destinationImages["Bali, Indonesia"],
      expiresIn: "24h",
    },
    {
      id: 2,
      destination: "Maldives",
      description: "7-night overwater bungalow + flights",
      price: "$3,000",
      originalPrice: "$3,900",
      image: destinationImages["Maldives"],
      expiresIn: "12h",
    },
    {
      id: 3,
      destination: "Santorini, Greece",
      description: "4-night luxury suite + private tour",
      price: "$2,800",
      originalPrice: "$3,500",
      image: destinationImages["Santorini, Greece"],
      expiresIn: "36h",
    },
    {
      id: 4,
      destination: "Amalfi Coast, Italy",
      description: "6-night coastal villa + private chef",
      price: "$4,200",
      originalPrice: "$5,100",
      image: destinationImages["Amalfi Coast, Italy"],
      expiresIn: "48h",
    },
    {
      id: 5,
      destination: "Swiss Alps",
      description: "5-night luxury chalet + ski passes",
      price: "$3,600",
      originalPrice: "$4,500",
      image: destinationImages["Swiss Alps"],
      expiresIn: "18h",
    },
    {
      id: 6,
      destination: "Kyoto, Japan",
      description: "4-night traditional ryokan + cultural tours",
      price: "$2,900",
      originalPrice: "$3,600",
      image: destinationImages["Kyoto, Japan"],
      expiresIn: "72h",
    },
  ]

  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (shouldFail) {
        reject(new Error("Failed to fetch deals"))
      } else {
        resolve(mockDeals)
      }
    }, 1000)
  })
}

// Helper function to get a random expiration time (for more dynamic data)
export const getRandomExpirationTime = () => {
  const hours = [6, 12, 18, 24, 36, 48, 72]
  const randomIndex = Math.floor(Math.random() * hours.length)
  return `${hours[randomIndex]}h`
}

