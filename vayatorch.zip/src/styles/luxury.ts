// Luxury color palette for the application
export const luxuryPalette = {
  background: "#121214", // Dark background
  cardBg: "rgba(18, 18, 22, 0.8)", // Card background with transparency
  text: "rgba(255, 255, 255, 0.9)", // Main text color
  textMuted: "rgba(255, 255, 255, 0.7)", // Secondary text color
  accent: "#d4af37", // Gold accent color
  accentLight: "#f5cc59", // Lighter gold for gradients
  secondary: "#2c2c2c", // Secondary dark color
  border: "rgba(255, 255, 255, 0.05)", // Subtle border color
  error: "#ff6b6b", // Error color
  success: "#4BB543", // Success color
}

// Gradient presets
export const luxuryGradients = {
  gold: "linear-gradient(135deg, #d4af37 0%, #f5cc59 100%)",
  dark: "linear-gradient(135deg, #121214 0%, #1e1e24 100%)",
}

